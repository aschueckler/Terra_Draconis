/*
BasilMod::HorseTaxi mod.
2015 Basil Semuonov

Usage.

Installation
1) Place this file (config.cs) and (horsetaxi.cs.dso) to folder "BasilMod/horsetaxi/" of server root.
2) add this line to the end of file "main.cs" of the server:
exec("BasilMod/horsetaxi/horsetaxi.cs");
3) Fill configuration file with info
4) Start server

Configuration
1) Register horsetaxi points with command BasilMod::horsetaxi_register, options explained below.
2) Start server.
3) If configuration is changed, you can reload config by executing this command at server:
exec("BasilMod/horsetaxi/horsetaxi.cs");

Available variables at config file:
1) $BasilMod::horsetaxi::show_coords = false; - enable display of current coords on server startup
2) $BasilMod::horsetaxi::enable = true; - enable horsetaxi by default on server startup

Horsetaxi registration;
BasilMod::horsetaxi_register(
	"Getting you a fresh horse from stables...",	//Message to be shown prior to horse recieving. "\n" is line separation. Message is center aligned. 4 lines allowed.
	3, 												//Timeout, how long you should stay on the horsetaxi. If you step out, you will not recieve horse
	"1049 74 0",									//Coordinates of source point. "X Y Z". Coords can be negative. To get coords, enable "show_coords" option, and write them done, while you are in GM mode.
	2								//Radius of source point for activating horsetaxi
);

Available function from the server console:
1) BasilMod::horsetaxi_enable(); - enable all registered taxi spots
2) BasilMod::horsetaxi_disable(); - disable all registered taxi spots
3) BasilMod::horsetaxi_showCoords(); - enable display of current coords for active GM characters
4) BasilMod::horsetaxi_hideCoords(); - disable display of current coords for active GM characters

*/

$BasilMod::horsetaxi::show_coords = true; //Show coords hint message for GM characters
$BasilMod::horsetaxi::enable = true; //Enable on server startup


// Wharf Taxi
BasilMod::horsetaxi_register("\n\nThe gods sense your desire for faster travel and bless you with a horse...", 3, "1260.28 212.827 1012.2", 10);


/*
//example horsetaxi points
BasilMod::horsetaxi_register("\n\nGetting you a fresh horse from stables...", 3, "1049 74 1005", 2); //Register new horsetaxi
BasilMod::horsetaxi_register("\n\nGetting you a fresh horse from stables...", 3, "1049 65 1005", 2);	//Register new horsetaxi
*/