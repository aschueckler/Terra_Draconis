/*
	BasilMod::SafeZone configuration
	2015 Basil Semuonov
	
Usage.

Installation
1) Place this file (config.cs) and (safezone.cs.dso) to folder "BasilMod/safezone/" of server root.
2) add this line to the end of file "main.cs" of the server:
exec("BasilMod/safezone/safezone.cs");
3) Fill configuration file with info
4) Start server

Configuration
1) Register safezones with command BasilMod::safezone_register, options explained below.
2) Start server.
3) If configuration is changed, you can reload config by executing this command at server:
exec("BasilMod/safezone/safezone.cs");

Available variables at config file:
1) $BasilMod::safezone::show_coords = false; - enable display of current coords on server startup
2) $BasilMod::safezone::enable = true; - enable safezones by default on server startup

Safezone registration:

BasilMod::safezone_register(
	"1049 74 1010",					//Coordinates of source point. "X Y Z". Coords can be negative. To get coords, enable "show_coords" option, and write them done, while you are in GM mode.
	1,								//Radius of safezone zone.
	"You enter Trade City.",		//Message to be shown when you enter safe spot zone
	"You left Trade City.",			//Message to be shown when you leave safe spot zone
	"You cannot attack here!",		//Message to be shown when players tries to attack
	true,							//Show messages at System chat window
	true,							//Show messages at Local chat window
	true							//Show messages at Center of the screen
);

Available function from the server console:
1) BasilMod::safezone_enable(); - enable all registered safezones
2) BasilMod::safezone_disable(); - disable all registered safezones
3) BasilMod::safezone_showCoords(); - enable display of current coords for active GM characters
4) BasilMod::safezone_hideCoords(); - disable display of current coords for active GM characters

*/

$BasilMod::safezone::show_coords = false; //Show coords hint message for GM characters
$BasilMod::safezone::enable = true; //Enable on server startup

BasilMod::safezone_register("1319.42 299.141 1020.78", 40, "<color:00ff00>You have entered Newman's Warf <color:ff0000>No Arms Allowed.", "<color:00ff00>You left Trade City. You are easy target now, Bon voyage!", "<color:ff0000>You cannot attack at this spot!", true, true, true); //Register new safe spot
