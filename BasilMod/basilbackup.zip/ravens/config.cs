/*
	BasilMod::Ravens server configuration file
	2015 Basil Semuonov
*/

$BasilMod::Ravens::onlyGuildMembers = false;
$BasilMod::Ravens::pickTimeout = 300000;
$BasilMod::Ravens::minMessageLength = 5;