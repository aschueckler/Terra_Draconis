/*
	BasilMod::NPC Server configuration file
	2015 Basil Semuonov

	Example config

%npc = BasilMod::npc_create(ID, "position", "rotation");
%npc.addIdle("state1", "lowerbound_duration upperbound_duration", "hands");
%npc.addIdle("state2", "lowerbound_duration upperbound_duration", "hands");
%npc.addIdle("state3", "lowerbound_duration upperbound_duration", "hands");

%zone = BasilMod::npc_zone("position", "radius", "lowerbound_delay upperbound_delay", "state", "hands");
%zone.addNpc(%npc);
*/

//NPC: Guard1
// position = "937.672 248.641 1005.21";
// rotation = "0 0 1 92.6312";
%npc1 = BasilMod::npc_create(11, "937.672 248.641 1005.21", "0 0 1 92.6312");
%npc1.addIdle("idle1", "2000 4000");
%npc1.addIdle("1h trickmove", "6000 7000", 4);
//NPC: Guard2
// position = "937.944 255.516 1005.08";
// rotation = "0 0 1 86.38";
%npc2 = BasilMod::npc_create(11, "937.944 255.516 1005.08", "0 0 1 86.38");
%npc2.addIdle("idle1", "1000 5000");
%npc2.addIdle("1h trickmove2", "6000 10000", 4);

//ZONE: Greet Zone
// position = "942.299 251.971 1005.21";
%zone = BasilMod::npc_zone("942.299 251.971 1005.21", "4", "0 500", "honor");
%zone.add(%npc1);
%zone.add(%npc2);
