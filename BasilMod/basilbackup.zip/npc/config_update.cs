//NPC: CitSit
// position = "1260.25 174.685 1011.99";
// rotation = "0 0 1 2.13102";
%npc = BasilMod::npc_create(XXX, "1260.25 174.685 1011.99", "0 0 1 2.13102");
//%npc.addIdle("idle1", "5000 1000", 0);
