/*
	BasilMod::NPC Server configuration file
	2015 Basil Semuonov

	Example config

%npc = BasilMod::npc_create(ID, "position", "rotation");
%npc.addIdle("state1", "lowerbound_duration upperbound_duration", "hands");
%npc.addIdle("state2", "lowerbound_duration upperbound_duration", "hands");
%npc.addIdle("state3", "lowerbound_duration upperbound_duration", "hands");

%zone = BasilMod::npc_zone("position", "radius", "lowerbound_delay upperbound_delay", "state", "hands");
%zone.addNpc(%npc);
*/


//HQ SHOP

//NPC: Guard1
// position = "1204.94 173.406 1016.41";
// rotation = "0 0 -1 22.8405";
%HQIntGuardHQOutGuard1 = BasilMod::npc_create(52, "1204.94 173.406 1016.41", "0 0 -1 22.8405");
//%npc.addIdle("idle1", "5000 1000", 0);

//NPC: Guard2
// position = "1197.42 172.713 1015.77";
// rotation = "0 0 1 20.0886";
%HQIntGuard = BasilMod::npc_create(52, "1197.42 172.713 1015.77", "0 0 1 20.0886");
//%npc.addIdle("idle1", "5000 1000", 0);

//NPC: Guard3
// position = "1197.62 163.865 1016.31";
// rotation = "0 0 1 88.1981";
%HQOutGuard2 = BasilMod::npc_create(52, "1197.62 163.865 1016.31", "0 0 1 88.1981");
//%npc.addIdle("idle1", "5000 1000", 0);

//ZONE: HQOutZ
// position = "1201.2 178.963 1016.43";
%HQOutZ = BasilMod::npc_zone("1201.2 178.963 1016.43", "4", "0 500", "honor", 0);
%HQOutZ.add(%HQOutGuard1);

//ZONE: HQOutZ
// position = "1201.2 178.963 1016.43";
%HQOutZ2 = BasilMod::npc_zone("1201.2 178.963 1016.43", "4", "0 500", "honor", 0);
%HQOutZ2.add(%HQOutGuard2);

//ZONE: HQShopInt
// position = "1201.23 168.541 1016.31";
%HQShopInt = BasilMod::npc_zone("1201.23 168.541 1016.31", "4", "0 500", "honor", 0);
%HQShopInt.add(%HQIntGuard);


//BAR


//NPC: BarGuard
// position = "1212.05 197.49 1017.84";
// rotation = "0 0 1 82.0401";
%BarGuard = BasilMod::npc_create(52, "1212.05 197.49 1017.84", "0 0 1 82.0401");
//%npc.addIdle("idle1", "5000 1000", 0);


//ZONE: BarGuardZ
// position = "1214.78 194.291 1018.02";
%BarGuardZ = BasilMod::npc_zone("1214.78 194.291 1018.02", "4", "0 500", "honor", 0);
%BarGuardZ.add(%BarGuard);

//NPC: Barkeep1
// position = "1206.5 205.596 1018.91";
// rotation = "0 0 1 176.995";
%Barkeep = BasilMod::npc_create(53, "1206.5 205.596 1018.91", "0 0 1 176.995");
%Barkeep.addIdle("cooking", "5000 1000", 0);

//ZONE: BarFront
// position = "1206.27 200.178 1018.09";
%BarFront = BasilMod::npc_zone("1206.27 200.178 1018.09", "4", "0 500", "welcome", 0);
%BarFront.add(%Barkeep);

//ZONE: BarBack
// position = "1213.89 206.868 1018.91";
%BarBack = BasilMod::npc_zone("1213.89 206.868 1018.91", "4", "0 500", "welcome", 0);
%BarBack.add(%Barkeep);


//TOWN SQUARE

//NPC: Cook
// position = "1244.42 180.733 1012.22";
// rotation = "0 0 1 26.3176";
%Cook = BasilMod::npc_create(54, "1244.42 180.733 1012.22", "0 0 1 26.3176");
%Cook.addIdle("cooking", "5000 1000", 0);

//ZONE: CookZ
// position = "1245.32 186.875 1012.19";
%CookZ = BasilMod::npc_zone("1245.32 186.875 1012.19", "4", "0 500", "welcome", 0);
%CookZ.add(%Cook);


//NPC: SlaveGuard1
// position = "1261.32 168.138 1009.2";
// rotation = "0 0 1 95.0811";
%SlaveGuard1 = BasilMod::npc_create(52, "1261.32 168.138 1009.2", "0 0 1 95.0811");
//%npc.addIdle("idle1", "5000 1000", 0);

//NPC: SlaveGuard2
// position = "1261.42 160.04 1007.48";
// rotation = "0 0 1 74.1963";
%SlaveGuard2 = BasilMod::npc_create(52, "1261.42 160.04 1007.48", "0 0 1 74.1963");
//%npc.addIdle("idle1", "5000 1000", 0);

//ZONE: SMarketGuard
// position = "1267.1 164.183 1007.2";
%SMarketGuard = BasilMod::npc_zone("1267.1 164.183 1007.2", "4", "0 500", "honor", 0);
%SMarketGuard.add(%SlaveGuard1);

//ZONE: SMarketGuard
// position = "1267.1 164.183 1007.2";
%SMarketGuard2 = BasilMod::npc_zone("1267.1 164.183 1007.2", "4", "0 500", "honor", 0);
%SMarketGuard2.add(%SlaveGuard2);


//TOURNAMENT GATE

//ZONE: TournyGuard
// position = "1312.45 176.287 1001.79";
%TournyGuard = BasilMod::npc_zone("1312.45 176.287 1001.79", "4", "0 500", "honor", 0);
%TournyGuard.add(%TournyGuard1);

//ZONE: TournyGuard
// position = "1312.45 176.287 1001.79";
%TournyGuard2 = BasilMod::npc_zone("1312.45 176.287 1001.79", "4", "0 500", "honor", 0);
%TournyGuard2.add(%TournyGuard2);

//NPC: TournyGuard1
// position = "1319.07 180.158 1001.71";
// rotation = "0 0 -1 82.1666";
%TournyGuard1 = BasilMod::npc_create(52, "1319.07 180.158 1001.71", "0 0 -1 82.1666");
//%TournyGuard1.addIdle("idle1", "5000 1000", 0);

//NPC: TournyGuard2
// position = "1319.31 172.455 1001.68";
// rotation = "0 0 -1 97.2671";
%TournyGuard2 = BasilMod::npc_create(52, "1319.31 172.455 1001.68", "0 0 -1 97.2671");
//%TournyGuard2.addIdle("idle1", "5000 1000", 0);
