/*
	BasilMod::NPC Server configuration file
	2015 Basil Semuonov

	Example config

%npc = BasilMod::npc_create(ID, "position", "rotation");
%npc.addIdle("state1", "lowerbound_duration upperbound_duration", "hands");
%npc.addIdle("state2", "lowerbound_duration upperbound_duration", "hands");
%npc.addIdle("state3", "lowerbound_duration upperbound_duration", "hands");

%zone = BasilMod::npc_zone("position", "radius", "lowerbound_delay upperbound_delay", "state", "hands");
%zone.addNpc(%npc);
*/

//NPC: saw1
// position = "1061.1 229.051 1011.64";
// rotation = "0 0 1 159.604";
%npc = BasilMod::npc_create(10, "1061.1 229.051 1011.64", "0 0 1 159.604");
%npc.addIdle("sawing", "3000 4000", 4);
%npc.addIdle("idle1", "2000", 4);
%npc.addIdle("idle2", "2000 3000", 4);
//NPC: Cut 1
// position = "1056.41 236.077 1011.9";
// rotation = "0 0 1 41.8029";
%npc = BasilMod::npc_create(7, "1056.41 236.077 1011.9", "0 0 1 41.8029");
%npc.addIdle("treecut", "5000 7000", 4);
%npc.addIdle("fatigue1", "2000 3000", 4);
%npc.addIdle("fatigue2", "3000 3000", 4);
//NPC: Cut 2
// position = "1061.78 236.702 1012.7";
// rotation = "0 0 -1 54.8603";
%npc = BasilMod::npc_create(8, "1061.78 236.702 1012.7", "0 0 -1 54.8603");
%npc.addIdle("treecut", "3000 4000", 4);
%npc.addIdle("idle1", "2000", 4);
%npc.addIdle("idle2", "2000 3000", 4);
//%npc.addIdle("Pray", 5000);
//NPC: saw 2
// position = "1050.78 213.681 1009.58";
// rotation = "0 0 1 68.6919";
%npc = BasilMod::npc_create(10, "1050.78 213.681 1009.58", "0 0 1 68.6919");
%npc.addIdle("sawing", "3000 4000", 4);
%npc.addIdle("idle1", "2000", 4);
%npc.addIdle("idle2", "2000 3000", 4);

//NPC: builder 1
// position = "1039.48 213.696 1009.06";
// rotation = "0 0 1 230.202";
%npc = BasilMod::npc_create(9, "1039.48 213.696 1009.06", "0 0 1 230.202");
%npc.addIdle("nail", "3000 4000", 4);
%npc.addIdle("idle1", "2000", 4);
%npc.addIdle("idle2", "2000 3000", 4);

//ZONE: Builder 1
// position = "1034.62 210.162 1008.64";
%zone = BasilMod::npc_zone("1034.62 210.162 1008.64", "4", "0 500", "welcome");
%zone.add(%npc);
