/*
	BasilMod::Tides. server config
	2016 Basil Semuonov
*/

$BasilMod::tides::highlevel = 2;
$BasilMod::tides::lowlevel = -5;
$BasilMod::tides::enabled = true;