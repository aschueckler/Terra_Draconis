/*
	BasilMod::ZoneMessage configuration
	2015 Basil Semuonov
	
Usage.

Installation
1) Place this file (config.cs) and (zonemessage.cs.dso) to folder "BasilMod/zonemessage/" of server root.
2) add this line to the end of file "main.cs" of the server:
exec("BasilMod/zonemessage/zonemessage.cs");
3) Fill configuration file with info
4) Start server

Configuration
1) Register zonemessages with command BasilMod::zonemessage_register, options explained below.
2) Start server.
3) If configuration is changed, you can reload config by executing this command at server:
exec("BasilMod/zonemessage/zonemessage.cs");

Available variables at config file:
1) $BasilMod::zonemessage::enable = true; - enable zonemessages by default on server startup

zonemessage registration:

BasilMod::zonemessage_register(
	"1049 74 1010",					//Coordinates of source point. "X Y Z". Coords can be negative.
	1,								//Radius of zonemessage zone.
	"Welcome to trade district.",	//Message to be shown when you enter zone
	true,							//Show messages at System chat window
	true,							//Show messages at Local chat window
	true							//Show messages at Center of the screen
);

Available function from the server console:
1) BasilMod::zonemessage_enable(); - enable all registered zonemessages
2) BasilMod::zonemessage_disable(); - disable all registered zonemessages

*/
$BasilMod::zonemessage::enable = true; //Enable on server startup

BasilMod::zonemessage_register("131 117 1010", 10, "<color:00ff00>Welcome to trade district.", true, true, true); //Register new zone